﻿using ConsoleApp15;
using System;
using System.Collections.Generic;

namespace ConsoleApp15
{
    class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirthday { get; set; }
        public int TutitionFees { get; set; }

        public int Id { get; set; }
      public  List<Courses> Courses = new List<Courses>();
        public List<SmallAssigment> Assignment = new List<SmallAssigment>();

        public Student(int id,string firstName, string lastName, DateTime dateOfBirthday, int tutitionFees)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            DateOfBirthday = dateOfBirthday;
            TutitionFees = tutitionFees;
        }
    }
}
