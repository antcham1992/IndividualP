﻿using System;
using System.Collections.Generic;

namespace ConsoleApp15
{
    class Courses
    {
        public string Title { get; set; }
        public int Stream { get; set; }

        public string Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public List<Student> Student { get; set; } = new List<Student>();
     public List<Trainer> Trainer { get; set; }= new List<Trainer>();
        public Assignment Assignments { get; set; } = new Assignment();
        public List<Assignment> Assi { get; set; } = new List<Assignment>();
        public List<SmallAssigment> smallAssigments = new List<SmallAssigment>();
        public int Id { get; set; }

        public Courses(int id,string title, int stream, string type, DateTime startDate, DateTime endDate)
        {
            Id = id;
            Title = title;
            Stream = stream;
            Type = type;
            StartDate = startDate;
            EndDate = endDate;

        }

       
    }
    
}
