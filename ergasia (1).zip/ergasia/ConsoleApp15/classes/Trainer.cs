﻿using ConsoleApp15;
using System.Collections.Generic;

namespace ConsoleApp15
{
    class Trainer
    {
        public Trainer(int id,string firstName, string lastName, string subject)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Subject = subject;
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Subject { get; set; }
        public int Id { get; set; }
        public List<Courses> Courses { get; set; }= new List<Courses>();
    }
}
