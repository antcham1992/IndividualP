﻿using ConsoleApp15;
using System;
using System.Collections.Generic;

namespace ConsoleApp15
{
    class Assignment
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public Assignment(int id, string title, string description, DateTime subDateTime, int oralMark, int totalMark)
        {
            Id = id;
            Title = title;
            Description = description;
            SubDateTime = subDateTime;
            OralMark = oralMark;
            TotalMark = totalMark;
        }

        public Assignment()
        {
        }

        public Assignment(int id, string title)
        {
            Id = id;
            Title = title;
        }

        

        public DateTime SubDateTime { get; set; }

        public int OralMark { get; set; }

        public int TotalMark { get; set; }
        public List<SmallAssigment> smallAssigment { get; set; } = new List<SmallAssigment>();
        public List<Courses> Courses { get; set; } = new List<Courses>();
        public List<Student> Student { get; set; } = new List<Student>();
       
    }

    class SmallAssigment : Assignment
    {

        public SmallAssigment(int id, string title, string description, DateTime subDateTime, int oralMark, int totalMark) : base(id, title, description, subDateTime, oralMark, totalMark)
        {

        }
        public Assignment Assignment { get; set; } = new Assignment();
    }

   
}