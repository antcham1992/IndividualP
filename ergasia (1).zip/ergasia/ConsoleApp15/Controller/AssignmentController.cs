﻿using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using ConsoleApp15.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
   class AssignmentController
    {
        AssignmentServices assignment = new AssignmentServices();
        public  void ShowAssignment()
        {
            Console.Clear();
           
            var allAssignment = assignment.GetAssignment();
            ViewAssigment.ShowAssignment(allAssignment);
        }
       

        public void CreateAssignment()
        {

            var assi = ViewAssigment.CreateAssignment();
            var smallassi = ViewAssigment.CreateSmallAssigment();
            assignment.Add(assi,smallassi);

        }
        public void EditTitleAssignment()
        {
            var assi = ViewAssigment.EditAssignment();
            
            assignment.Edittitle(assi.Id, assi);
        }
        public void EditRowAssignment()
        {
            var assi = ViewAssigment.EditRowAssignment();
            var smallassi = ViewAssigment.EditSmallAssignment();
            assignment.EditRow(assi.Id, smallassi.Id, assi,smallassi);
        }

        public void DeleteAssignment()
        {

            var assi = ViewAssigment.DeleteAssi();
            assignment.Delete(assi);

        }
    }
}
