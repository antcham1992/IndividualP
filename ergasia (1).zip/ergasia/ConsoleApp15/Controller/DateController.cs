﻿using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using ConsoleApp15.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
   class DateController
    {
       DateServices date = new DateServices();
        ViewDate date1 = new ViewDate();
        
       public void GetDate()
        {
           
            var a1=date.GetAssignment();
            date1.ShowDate(a1);
        }

       
    }
}
