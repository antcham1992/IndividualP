﻿using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using ConsoleApp15.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class AssiPerCourseController
    {
        ViewAssignmentPerCourse courses = new ViewAssignmentPerCourse();
        AssignmentPerCourseServices assignm = new AssignmentPerCourseServices(); 
        public void ShowAssiPerCourse()
        {
            Console.Clear();
           
                Console.Clear();
              
                var allAssignm = assignm.GetCourses();
            courses.ShowCourses(allAssignm);

               }


       
        public void EditCourse()
        {
            var courseId = courses.CourseId();
            var asId = courses.AssiId();
            assignm.Edit(courseId, asId);
        }

        public void DeleteCourse()
        {

            var courseId = courses.CourseId();
            assignm.Delete(courseId);

        }
        public void DeleteAssi()
        {

            var courseId = courses.CourseId();
            var asId = courses.AssiId();
            assignm.DeleteStudent(courseId, asId);

        }
    }
}
