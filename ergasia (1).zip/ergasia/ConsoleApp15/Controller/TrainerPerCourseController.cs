﻿using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using ConsoleApp15.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class TrainerPerCourseController
    {
        ViewTrainerPerCourse courses = new ViewTrainerPerCourse();
        TrainerPerCourseServices trainer = new TrainerPerCourseServices();
        public void ShowTrainerPerCourse()
        {
            Console.Clear();
           
            var allTrainerspercourse = trainer.GetCourses();
            courses.ShowCourses(allTrainerspercourse);

        }


       
        public void EditCourse()
        {
            var courseId = courses.CourseId();
            var trId = courses.TrainerId();
            trainer.Edit(courseId, trId);
        }

        public void DeleteCourse()
        {

            var courseId = courses.CourseId();
            trainer.Delete(courseId);

        }
        public void DeleteTrainer()
        {

            var courseId = courses.CourseId();
            var trId = courses.TrainerId();
            trainer.DeleteStudent(courseId, trId);

        }
    }
}
