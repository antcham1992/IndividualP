﻿using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using ConsoleApp15.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class AssignmentPerCoursePerStudentController
    {
        ViewAssignmentPerCourse courses = new ViewAssignmentPerCourse();
        AssignmentPerCoursePerStudentServices assignm = new AssignmentPerCoursePerStudentServices();
        public  void ShowAssiPerCourse()
        {
            Console.Clear();
            AssignmentPerCoursePerStudentServices assignm = new AssignmentPerCoursePerStudentServices();
            var allAssignm = assignm.GetCourses();
            ViewAssignmentPerCoursePerStudent.ShowCourses(allAssignm);



        }


       
        public void EditCourse()
        {
            var courseId = courses.CourseId();
            var asId = courses.AssiId();
          //  assignm.Edit(courseId, asId);
        }

        public void DeleteCourse()
        {

            var courseId = courses.CourseId();
        //    assignm.Delete(courseId);

        }
        public void DeleteAssi()
        {

            var courseId = courses.CourseId();
            var asId = courses.AssiId();
           // assignm.DeleteStudent(courseId, asId);

        }
    }
}
