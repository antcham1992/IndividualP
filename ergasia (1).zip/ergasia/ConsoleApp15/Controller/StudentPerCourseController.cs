﻿using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using ConsoleApp15.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class StudentPerCourseController
    {
        ViewStudentPerCourseServices courses = new ViewStudentPerCourseServices();
        StudentPerCourseServices student = new StudentPerCourseServices();
        public void ShowStudentPerCourse()
        {
            Console.Clear();
           
            var allStudentspercourse = student.GetCourses();
            courses.ShowStudentPerCourses(allStudentspercourse);

        }


       
        public void EditCourse()
        {
            var courseId = courses.CourseId();
            var stuId = courses.StudentId();
            student.Edit(courseId, stuId);
        }

        public void DeleteCourse()
        {

            var courseId = courses.CourseId();
            student.Delete(courseId);

        }
        public void DeleteStudent()
        {

            var courseId = courses.CourseId();
            var stuId = courses.StudentId();
            student.DeleteStudent(courseId, stuId);

        }
    }
}
