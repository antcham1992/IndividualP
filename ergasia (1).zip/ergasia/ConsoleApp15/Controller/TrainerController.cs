﻿using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class TrainerController
    {
        TrainerServices trainers = new TrainerServices();
      
        public void ShowTrainer()
        {
            Console.Clear();
            
            var allTrainer = trainers.GetTrainers();
            ViewTrainer.ShowTrainers(allTrainer);
        }
        public void CreateTrainer()
        {
            
            var trainer = ViewTrainer.CreateTrainer();
            int tr = trainer.Count;
            trainers.Add(trainer,tr);
           
        }
        public void EditTrainer()
        {
            var trainer = ViewTrainer.EditTrainer();
            trainers.Edit(trainer.Id, trainer);
        }
        public void DeleteTrainer()
        {

            var trainer = ViewTrainer.DeleteTrainer();
            trainers.Delete(trainer);

        }
    }
}
