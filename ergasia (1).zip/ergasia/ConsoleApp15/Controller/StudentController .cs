﻿using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using ConsoleApp15.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class StudentController
    {
        StudentServices students = new StudentServices();
      
        public void ShowStudent()
        {
            Console.Clear();
            
            var allStudent = students.GetStudent();
            ViewStudent.ShowStudent(allStudent);
        }

        public  void ShowStudentMoreCourse()
        {
            Console.Clear();

            var allStudent = students.GetStudent();
            ViewStudentMoreCourse.ShowStudentCourses(allStudent);
        }
        public void CreateStudent()
        {
            
            var student = ViewStudent.CreateStudent();
            int stu = student.Count;
            students.Add(student,stu);
           
        }
        public void EditStudent()
        {
            var student = ViewStudent.EditStudent();
            students.Edit(student.Id, student);
        }
        public void DeleteStudent()
        {

            var student = ViewStudent.DeleteStudent();
            students.Delete(student);

        }
    }
}
