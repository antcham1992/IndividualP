﻿using ConsoleApp15.Helper;
using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Controller
{
    class CourseController
    {
        CoursesServices courses = new CoursesServices();
        public  void ShowCourse()
        {
            Console.Clear();
           
            var allCourses = courses.GetCourses();
            Viewcourses.ShowCourses(allCourses);
        }
       
       

        public  void CreateCourse()
        {
                      
            var course = Viewcourses.CreateCourse();
            int number = course.Count;
            courses.Add(course,number);
            
        }
        public void EditCourse()
        {
            var course = Viewcourses.EditCourse();
            
            courses.Edit(course.Id,course.Stream, course);
        }

        public void DeleteCourse()
        {

            var course = Viewcourses.DeleteCourse();
            courses.Delete(course);

        }
    }
}
