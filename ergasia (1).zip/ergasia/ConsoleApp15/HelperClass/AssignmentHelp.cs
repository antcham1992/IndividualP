﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Helper
{
    class AssignmentHelp
    {
        public static int InputId(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            do
            {

                if (result <= 0)
                {
                    Console.WriteLine("Ξαναδώστε αριθμό μεγαλύτερο του 0");
                    result = Convert.ToInt32(Console.ReadLine());
                }


            } while (result <= 0);
            return result;
           
        }
        public static string InputTitle(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
        public static string InputDescription(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
        public static DateTime SubDateTime(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
           
            string result = Console.ReadLine();
            try
            {
                DateTime result1 = DateTime.Parse(result);
               
                return result1;
            }
            catch
            {

                return SubDateTime("Ξαναδώστε ημερομηνία");
            }
        }


        public static int OralMark(string placeholder)
        {
            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            do
            {

                if (result <= 0 || result > 100)
                {
                    Console.WriteLine("Ξαναδώστε αριθμό μεγαλύτερο του 0 και μικρότερο του 100");
                    result = Convert.ToInt32(Console.ReadLine());
                }


            } while (result <= 0 || result > 100);
            return result;
        }


        public static int TotalMark(string placeholder)
        {

            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            do
            {

                if (result <0 || result > 100)
                {
                    Console.WriteLine("Ξαναδώστε αριθμό μεγαλύτερο του 0 και μικρότερο του 100");
                    result = Convert.ToInt32(Console.ReadLine());
                }


            } while (result <0 || result > 100);
            return result;
        }

      
    }
}

