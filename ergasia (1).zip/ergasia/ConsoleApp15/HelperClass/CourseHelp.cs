﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Helper
{
    class CourseHelp
    {
        public static int InputNumber(string placeholder)
        {


            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            do
            {

                if (result <= 0)
                {
                    Console.WriteLine("Ξαναδώστε αριθμό μεγαλύτερο του 0");
                    result = Convert.ToInt32(Console.ReadLine());
                }


            } while (result <= 0);
            return result;
        }
        public static int InputId(string placeholder)
        {
            
           
            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            do
            {

                if (result <= 0)
                {
                    Console.WriteLine("Ξαναδώστε αριθμό μεγαλύτερο του 0");
                    result = Convert.ToInt32(Console.ReadLine());
                }


            } while (result <= 0);
            return result;
        }
        public static string InputText(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            return result;
        }
        public static int InputStream(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            int result = Convert.ToInt32(Console.ReadLine());
            do
            {

                if (result <= 0)
                {
                    Console.WriteLine("Ξαναδώστε αριθμό μεγαλύτερο του 0");
                    result = Convert.ToInt32(Console.ReadLine());
                }


            } while (result <= 0);
            return result;
        }

        public static string InputType(string placeholder)
        {
            //try catch  & do while
            Console.WriteLine(placeholder);
            Menu();
            string Choise = Console.ReadLine();
            string result = "";
           
            switch (Choise)
                
            {
                case "1": result = "Full-Time"; break;
                case "2": result = "Part-Time"; break;
                default: result = InputType("Ξαναδιαλέξτε"); break;

            }
            return result;
        }

        public static DateTime StartDate(string placeholder)
        {
            Console.WriteLine(placeholder);

            string result = Console.ReadLine();
            try
            {
              DateTime  result1 = DateTime.Parse(result);
                return result1;
            }
            catch
            {
                
                return StartDate("Ξαναδώστε ημερομηνία"); 
            }

           

        }

        public static DateTime EndDate(string placeholder)
        {
            Console.WriteLine(placeholder);
            string result = Console.ReadLine();
            try
            {
                DateTime result1 = DateTime.Parse(result);
                return result1;
            }
            catch
            {

                return StartDate("Ξαναδώστε ημερομηνία");
            }

        }

        static void Menu()
        {
            Console.WriteLine("Πατήστε:");
            Console.WriteLine("1-Για Fulltime");
            Console.WriteLine("2-Για Parttime");
        }
    }
}
