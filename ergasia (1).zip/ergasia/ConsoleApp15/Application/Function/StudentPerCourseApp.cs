﻿using ConsoleApp15;
using ConsoleApp15.Controller;
using System;

namespace Final.Application
{
    class StudentCourseApp
    {
        public static void Course()
        {
            Console.Clear();
            StudentPerCourseController course = new StudentPerCourseController();

                string input = "";
                
                do
                {
                StudentCourseMenu.Menu();
                input = Console.ReadLine();
                    Console.Clear();
                    switch (input)
                    {
                        case "1": course.ShowStudentPerCourse(); break;
               
                        case "2":course.EditCourse(); break;
                        case "3": course.DeleteStudent(); break;
                       case "4": course.DeleteCourse(); break;
                     case "5": App.Run(); break;
                        default: Console.WriteLine("Ξαναδιαλέξτε"); break;
                    }


                } while (input != "5");
            }
        }
    }


