﻿using ConsoleApp15.Controller;
using Final.Application;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class UserInput
    {
        public static void CheckChoise1(string choiseInput1)
        {
           
            
            switch (choiseInput1)
            {
                case "0": CourseApp.Course(); break;
                case "1": TrainerApp.Trainer(); break;
                case "2": StudentApp.Student(); break;
                case "3": AssignmentApp.Assignment(); break;
                case "4": StudentCourseApp.Course(); break;
                case "5": TrainerCourseApp.Course(); break;
                case "6": AssiCourseApp.Course(); break;
                case "7": AssiCourseStuApp.Course(); break;
                case "8": DateApp.Date(); break;
                case "e": Console.WriteLine("Ευχαριστούμε!"); break;
                case "E": Console.WriteLine("Ευχαριστούμε!"); break;
                default: Console.WriteLine("Ξαναδιαλέξτε"); break;
            }

        }
    }
}
