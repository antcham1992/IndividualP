﻿using ConsoleApp15.Controller;
using Final.Application;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class DateApp
    {
       
        
        public static void Date()
        {
            DateController date = new DateController();

            Console.Clear();
            string input = "";

            do
            {
               
                DateMenu.Menu();
                input = Console.ReadLine();
                Console.Clear();
                switch (input)
                {
                    case "1": date.GetDate(); break;
                    case "2": App.Run(); break;
                    default: Console.WriteLine("Ξαναδιαλέξτε"); break;
                }


            } while (input != "2");
        }

    }
}
