﻿using ConsoleApp15;
using ConsoleApp15.Controller;
using System;

namespace Final.Application
{
    class StudentApp
    {
        public static void Student()
        {
            Console.Clear();
                StudentController student = new StudentController();

                string input = "";
                
                do
                {
                StudentMenu.Menu();
                input = Console.ReadLine();
                    Console.Clear();
                    switch (input)
                    {
                        case "1": student.ShowStudent(); break;
                        case "2": student.ShowStudentMoreCourse(); break;
                        case "3": student.CreateStudent(); break;
                        case "4":student.EditStudent(); break;
                        case "5":student.DeleteStudent(); break;
                        case "6": App.Run(); break;
                        default: Console.WriteLine("Ξαναδιαλέξτε"); break;
                    }


                } while (input != "6");
            }
        }
    }


