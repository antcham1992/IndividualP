﻿using ConsoleApp15;
using ConsoleApp15.Controller;
using System;

namespace Final.Application
{
    class AssiCourseStuApp
    {
        public static void Course()
        {
            Console.Clear();
            AssignmentPerCoursePerStudentController assi = new AssignmentPerCoursePerStudentController();

                string input = "";
                
                do
                {
                AssiCourseStuMenu.Menu();
                input = Console.ReadLine();
                    Console.Clear();
                    switch (input)
                    {
                        case "1": assi.ShowAssiPerCourse(); break;
                        
                     case "2": App.Run(); break;
                    default: Console.WriteLine("Ξαναδιαλέξτε"); break;
                    }


                } while (input != "2");
            }
        }
    }


