﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class App
    {
        public static void Run()

        {
           

            string choiseInput= ""; 
           
            do
            {

                if (choiseInput != "e" && choiseInput != "E")
                {
                    Console.Clear();
                    Regards.Welcome();
                    SecondMenu.SMenu();
                    choiseInput = Console.ReadLine();
                    UserInput.CheckChoise1(choiseInput);

                }
                else
                {
                    choiseInput = Console.ReadLine();
                    UserInput.CheckChoise1(choiseInput);
                   
                }

            } while (choiseInput != "e" && choiseInput != "E" );
        }
    }
}
