﻿using ConsoleApp15.Controller;
using ConsoleApp15.RepositoryService;
using ConsoleApp15.view;
using ConsoleApp15.View;
using Final.Application;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class Program
    {
        
        static void Main()
        {
            App.Run();

        }
      
    }
}

