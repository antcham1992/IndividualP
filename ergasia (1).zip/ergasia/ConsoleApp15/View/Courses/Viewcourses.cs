﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.view
{
    class Viewcourses
    {
        public static void ShowCourses(List<Courses> courses)
        {
            Console.WriteLine("-------------------------------------------ΜΑΘΗMAΤΑ-------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Id",-15}{"Τιτλος",-15}{"Κωδικός",-15}{"Τύπος",-15}{"Ημ/νία Εναρξής",-20}{"Ημ/νία Τέλους",-15}");
            Console.ResetColor();
           
            foreach (var co in courses)
            {
                Console.WriteLine($"{co.Id,-15}{co.Title,-15}{co.Stream,-15}{co.Type,-15}{co.StartDate,-20:dd/MM/yyyy}{co.EndDate,-20:dd/MM/yyyy}");

            }
        }

        public static List<Courses> CreateCourse()
        {
            
            int CourseNumber = CourseHelp.InputNumber("Δώστε αριθμό μαθημάτων");
            List<Courses> numberCourse = new List<Courses>();
            
            for (int i = 0; i < CourseNumber; i++)
            {
                Console.WriteLine((i+1)+"o Μάθημα");
               string title = CourseHelp.InputText("Δώστε Τίτλο");
             //  int stream = CourseHelp.InputStream("Δώστε κωδικό");
              string type = CourseHelp.InputType("Δώστε τύπο π.χ.Fulltime/Parttime");
              DateTime startDate = CourseHelp.StartDate("Δώστε ημερομηνία έναρξης π.χ.03/05/2022");
              DateTime endDate = CourseHelp.EndDate("Δώστε ημερομηνία ληξης π.χ.03/05/2022");

                Courses course = new Courses(0, title, 0, type, startDate, endDate);
                numberCourse.Add(course);
               
            }
           
            return numberCourse;
        }
        public static Courses EditCourse()
        {
            
            int id = CourseHelp.InputId("Δώστε Id μαθήματος");
            string title = CourseHelp.InputText("Δώστε Τίτλο");
           int stream = CourseHelp.InputStream("Δώστε κωδικό");
            string type = CourseHelp.InputType("Δώστε τύπο π.χ.Fulltime/Parttime");
            DateTime startDate = CourseHelp.StartDate("Δώστε ημερομηνία έναρξης π.χ.03/05/2022");
            DateTime endDate = CourseHelp.EndDate("Δώστε ημερομηνία ληξης π.χ.03/05/2022");

            Courses course = new Courses(id, title, stream, type, startDate, endDate);
            return course;
        }
       public static int DeleteCourse()
        {

            int CourserId = CourseHelp.InputId("Δώστε Id μαθήματος");
            return CourserId;
        }
    }
}
