﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.View
{
    class ViewAssignmentPerCourse
    {
        public  void ShowCourses(List<Courses> courses)
        {
            Console.WriteLine("------------------------------------ΑSSIGNMENT ΑΝΑ ΜΑΘΗMA------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Ιd",-15}{"Τιτλος",-15}{"Κωδικός",-15}{"Τύπος",-18}{"Τίτλος",-15}");
            Console.ResetColor();

            foreach (var co in courses)
            {
                Console.WriteLine($"{co.Id,-15}{co.Title,-15}{co.Stream,-15}{co.Type,-15}");
                foreach (var assi in co.Assi)
                {
                    Console.WriteLine("\t\t" + $"{"Id: "+assi.Id,47}{" "+assi.Title,15}");
                }
            }

           
        }

        public int CourseId()
        {
            int id = CourseHelp.InputId("Δώστε Id μαθήματος");
            return id;
        }

        public int AssiId()
        {
            int id = StudentHelp.InputId("Δώστε Id assignment");
            return id;
        }
    }
}

