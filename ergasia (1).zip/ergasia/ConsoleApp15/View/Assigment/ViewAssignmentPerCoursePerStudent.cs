﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.View
{
    class ViewAssignmentPerCoursePerStudent
    {
        public static void ShowCourses(List<Courses> courses)
        {
            Console.WriteLine("------------------------------------ΑSSIGNMENT ΑΝΑ ΜΑΘΗMA ΑΝΑ ΜΑΘΗΤΉ------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Id",-15}{"Τιτλος",-15}{"Κωδικός",-15}{"Τύπος",-18}{"Τίτλος",-15}");
            Console.ResetColor();
            foreach (var co in courses)
            {
                Console.WriteLine($"{co.Id,-15}{co.Title,-15}{co.Stream,-15}{co.Type,-15}");
                foreach (var assi in co.Assi)
                {
                    Console.WriteLine("\t\t" + $"{"Id: " + assi.Id,47}{" " + assi.Title,15}");
                    foreach ( var stu in assi.Student)
                    {
                        
                        if (co.Student.Contains(stu))
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("\t\t" + $"{stu.FirstName,55}{stu.LastName,15}");
                            Console.ResetColor();
                        }
                        
                        
                    }
                }
            }

        }
               
            }
        }
    

