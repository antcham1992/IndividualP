﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.View
{
    class ViewAssigment
    {
        public static void ShowAssignment(List<Assignment>assignments)
        {
            Console.WriteLine("-----------------------------------------------------------------------Assignments----------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Id",-10}{"Τιτλος",-25}{"Περιγραφή",-55}{"Παράδοση",-25}{"ΟralMark",-25}{"TotalMark",-25}");
            Console.ResetColor();
            foreach (var asi in assignments)
            {
                Console.WriteLine($"{asi.Id,-10}{asi.Title,-25}");
                Console.WriteLine();
               
                foreach (var item in asi.smallAssigment)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\t\t"+$"{"Id: "+item.Id,-10}{item.Title,-25}{item.Description,-40}{item.SubDateTime,-25:dd/MM/yyyy}{item.OralMark,-25}{item.TotalMark,-25}");
                    Console.WriteLine();
                    Console.ResetColor();
                }
                
            }
        }
        public static Assignment CreateAssignment()
        {
            string title = AssignmentHelp.InputTitle("Δώστε Τίτλο");
            Assignment assignment = new Assignment(0,title);
            return assignment;

        }

        public static List<SmallAssigment> CreateSmallAssigment()
        {
            SmallAssigment smallassignment = new SmallAssigment(0, "", "", new DateTime(2021, 01, 01), 0, 0);
            List<SmallAssigment> smallassi = new List<SmallAssigment>();
            
            for (int j = 0; j < 7; j++)
            {
                string title = AssignmentHelp.InputTitle("Δώστε Τίτλο Assignment");
                string description = AssignmentHelp.InputDescription("Δώστε περιγραφή");
                DateTime subdateTime = AssignmentHelp.SubDateTime("Δώστε ημερομηνία παράδοσης π.χ.03/05/2022");
                int oralMark = AssignmentHelp.OralMark("Δώστε προφορικό βαθμό");
                int totalMark = AssignmentHelp.TotalMark("Δώστε συνολικό βαθμο");
                smallassignment = new SmallAssigment(29, title, description, subdateTime, oralMark, totalMark);
               
                smallassi.Add(smallassignment);
                
            }
            return smallassi;
        }
        public static Assignment EditAssignment()
        {
            int id = AssignmentHelp.InputId("Δώστε Id Assignment");
            string title = AssignmentHelp.InputTitle("Δώστε Τίτλο");
            Assignment assignment = new Assignment(id, title);
            return assignment;

        }
        public static Assignment EditRowAssignment()
        {
            int id = AssignmentHelp.InputId("Δώστε Id Assignment");
             Assignment assignment = new Assignment(id, "");
            return assignment;

        }
        public static SmallAssigment EditSmallAssignment()
        {

            int id = AssignmentHelp.InputId("Δώστε Id γραμμής ");
            string title = AssignmentHelp.InputTitle("Δώστε Τίτλο");
            string description = AssignmentHelp.InputDescription("Δώστε περιγραφή");
            DateTime subdateTime = AssignmentHelp.SubDateTime("Δώστε ημερομηνία παράδοσης π.χ.03/05/2022");
            int oralMark = AssignmentHelp.OralMark("Δώστε προφορικό βαθμό");
            int totalMark = AssignmentHelp.TotalMark("Δώστε συνολικό βαθμο");

            SmallAssigment assignment = new SmallAssigment(id, title, description, subdateTime, oralMark, totalMark);
           
            return assignment;
        }
        public static int DeleteAssi()
        {
            Console.WriteLine("Δώστε Id Assignment");
            int AssiId = Convert.ToInt32(Console.ReadLine());
            return AssiId;
        }
    }
}
