﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.View
{
    class ViewDate
    {
        public void ShowDate(List<Assignment> smassi)
        {
            DateTime date = GiveDate();
            Console.WriteLine("-----------------------Assignments μαθητων την συγκεκριμένη ημ/νια--------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Όνομα",25}{"Τίτλος",14}{"Ημε/νια",43}");
            Console.ResetColor();

            foreach (var item in smassi)


            {
                
                foreach (var assi in item.smallAssigment.Distinct())
                {
                    if(assi.SubDateTime== date) {
                        foreach (var stu in assi.Student.Distinct())
                        {
                            
                            Console.WriteLine($"{stu.FirstName,25}{assi.Title,25}{assi.SubDateTime,35:dd/MM/yyyy}");
                            
                        }
                       
                        Console.WriteLine();
                        
                    }
                   


                }

                
            }
        }



        public DateTime GiveDate()
        {
            DateTime date = AssignmentHelp.SubDateTime("Δώστε Ημερ/νια π.χ.30/12/2021");
            return date;
        }

    }
}
        
    

