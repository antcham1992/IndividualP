﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.View
{
    class ViewTrainerPerCourse
    {
        public  void ShowCourses(List<Courses> courses)
        {
            Console.WriteLine("------------------------------------ΚΑΘΗΓΗΤΕΣ ΑΝΑ ΜΑΘΗMA------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Id",-15}{"Τιτλος",-15}{"Κωδικός",-15}{"Τύπος",-15}{"Όνομα",19}{"Επίθετο",25}");
            Console.ResetColor();

            foreach (var co in courses)
            {
                Console.WriteLine($"{co.Id,-15}{co.Title,-15}{co.Stream,-15}{co.Type,-15}");
                foreach (var tra in co.Trainer)
                {
                    Console.WriteLine( $"\t\t" + $"{"Id: " + tra.Id,48}{tra.FirstName,16}{tra.LastName,25}");
                }
            }


        }
        public int CourseId()
        {
            int id = CourseHelp.InputId("Δώστε Id μαθήματος");
            return id;
        }

        public int TrainerId()
        {
            int id = TrainerHelp.InputId("Δώστε Id καθήγητη");
            return id;
        }
    }
}
