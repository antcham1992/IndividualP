﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.view
{
    class ViewTrainer
    {
        public static void ShowTrainers(List<Trainer> trainers)
        {
            Console.WriteLine("--------------------ΚΑΘΗΓΗΤΕΣ--------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
         
            Console.WriteLine($"{"Id",-15}{"Ονομα",-15}{"Επίθετο",-15}{"Μάθημα",-15}");
            Console.ResetColor();
            foreach (var trai in trainers)
            {
                Console.WriteLine($"{trai.Id,-15}{trai.FirstName,-15}{trai.LastName,-15}{trai.Subject,-15}");
            }

            
        }

        public static List<Trainer> CreateTrainer()
        {
            Console.Clear();
            Console.WriteLine("Δώστε αριθμό καθηγητών");
            int number = Convert.ToInt32(Console.ReadLine());
           
            List<Trainer> trainerNumber = new List<Trainer>();
            for (int i = 0; i < number; i++)
            {
                Console.WriteLine((i+1)+"ος -Καθηγητής");
                string firstName = TrainerHelp.InputFName("Δώστε όνομα");
                string lastName = TrainerHelp.InputLName("Δώστε επίθετο");
                string subject = TrainerHelp.Subject("Δώστε Subject");

                Trainer trainer = new Trainer(0, firstName, lastName, subject);
                trainerNumber.Add(trainer);
                
            }
            return trainerNumber;
        }
        public static   Trainer EditTrainer()
        {
            
            int id = TrainerHelp.InputId("Δώστε Id καθηγητή");
           
            string firstName = TrainerHelp.InputFName("Δώστε όνομα");
            string lastName = TrainerHelp.InputLName("Δώστε επίθετο");
            string subject = TrainerHelp.Subject("Δώστε Subject");
            Trainer trainer = new Trainer(id, firstName, lastName, subject);
            return trainer;
        }
        public static int DeleteTrainer()
        {
           int trainerId = TrainerHelp.InputId("Δώστε Id καθηγητή");
            return trainerId;
        }

    }
}
