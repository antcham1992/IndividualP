﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.View
{
    class ViewStudent
    {
        public static void ShowStudent(List<Student> student)
        {
            Console.WriteLine("-------------------------------ΜΑΘΗΤΕΣ-------------------------------");

  
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Ιd",-15}{"Ονομα",-15}{"Επίθετο",-15}{"Ημ/νια",-15}{"Δίδακτρα",-15}");
            Console.ResetColor();
            foreach (var stu in student)
            {
                Console.WriteLine($"{stu.Id,-15}{stu.FirstName,-15}{stu.LastName,-15}{stu.DateOfBirthday,-15:dd/MM/yyyy}{stu.TutitionFees,-15}");
            }
        }

        public static List<Student> CreateStudent()
        {
            
            int StudentNumber = StudentHelp.InputNumber("Δώστε αριθμό μαθητών");
            List<Student> numberStudent = new List<Student>();
           
            for (int i = 0; i < StudentNumber; i++)
            {
                Console.WriteLine((i + 1) + "oς Μαθητής");
                string firstName = StudentHelp.InputFName("Δώστε όνομα");
                string lastName = StudentHelp.InputLName("Δώστε επίθετο");
                DateTime bitrhdayDate = StudentHelp.DateOfBirthday("Δώστε ημερομηνία γεννησης π.χ.03/05/1980");
                int tutionFees = StudentHelp.InputTutionFee("Δώστε δίδακτρα");

                Student student = new Student(0, firstName, lastName, bitrhdayDate, tutionFees);
                numberStudent.Add(student);
                
            }

            return numberStudent;
        }
        public static Student EditStudent()
        {

            int id = StudentHelp.InputId("Δώστε Id μαθητή");
            string firstName = StudentHelp.InputFName("Δώστε όνομα");
            string lastName = StudentHelp.InputLName("Δώστε επίθετο");
            DateTime bitrhdayDate = StudentHelp.DateOfBirthday("Δώστε ημερομηνία γεννησης π.χ.03/05/2022");
            int tutionFees = StudentHelp.InputTutionFee("Δώστε δίδακτρα");

            Student student = new Student(id, firstName, lastName, bitrhdayDate, tutionFees);

            
            return student;
        }
        public static int DeleteStudent()
        {
            int CourserId = StudentHelp.InputId("Δώστε Id μαθητή");
            return CourserId;
        }
    }
    }

