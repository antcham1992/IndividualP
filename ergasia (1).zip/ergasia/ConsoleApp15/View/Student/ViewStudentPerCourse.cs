﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.View
{
    class ViewStudentPerCourseServices
    {
        public  void ShowStudentPerCourses(List<Courses> courses)
        {
            Console.WriteLine("-------------------------------------------MΑΘΗΤΕΣ ΑΝΑ ΜΑΘΗMA-------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Id",-15}{"Τιτλος",-15}{"Κωδικός",-15}{"Τύπος",-15}{"Όνομα",16}{"Επίθετο",25}");
            Console.ResetColor();

            foreach (var co in courses)
            {
                Console.WriteLine($"{co.Id,-15}{co.Title,-15}{co.Stream,-15}{co.Type,-15}");
                foreach (var stu in co.Student)
                {
                    Console.WriteLine("\t\t"+ $"{"Id: "+stu.Id,45}{stu.FirstName,16}{stu.LastName,25}");
                }
            }


        }

        public  int CourseId()
        {
           int id= CourseHelp.InputId("Δώστε Id μαθήματος");
            return id;
        }

        public int StudentId()
        {
            int id = StudentHelp.InputId("Δώστε Id μαθήτη");
            return id;
        }
    }
}
