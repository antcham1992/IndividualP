﻿using ConsoleApp15.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.View
{
    class ViewStudentMoreCourse
    {
        public  static void ShowStudentCourses(List<Student> student)
        {
            Console.WriteLine("------------MΑΘΗΤΕΣ MΕ ΠΕΡΙΣΣΟΤΕΡΑ ΑΠΟ ΕΝΑ ΜΑΘΗΜΑΤΑ------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{"Ιd",-15}{"Ονομα",-15}{"Επίθετο",-15}{"Αριθμός μαθημάτων",-15}");
            Console.ResetColor();

            foreach (var stu in student)
            {
                if (stu.Courses.Count > 1)
                {
                    Console.WriteLine($"{stu.Id,-15}{stu.FirstName,-15}{stu.LastName,-15}{stu.Courses.Count,-15}");
                }
            }


        }

      
    }
}
