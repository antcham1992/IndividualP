﻿using System;

namespace ConsoleApp15
{
    class SecondMenu
    {
         public static void SMenu()
        {
           
            Console.WriteLine();
            Console.WriteLine("Eπιλέξτε μία απο τις παρακάτω επιλογές.");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Πατήστε 0 για να δείτε όλα τα μαθηματα");
            Console.WriteLine("Πατήστε 1 για να δείτε όλους τους καθηγητές");
            Console.WriteLine("Πατήστε 2 για να δείτε όλους τους μαθητές");
            Console.WriteLine("Πατήστε 3 για να δείτε όλα τα Assignments");
            Console.WriteLine("Πατήστε 4 για να δείτε όλους τους μαθητές ανα μάθημα");
            Console.WriteLine("Πατήστε 5 για να δείτε όλους τους καθηγητές ανα μάθημα");
            Console.WriteLine("Πατήστε 6 για να δείτε όλες τις εργασίες ανα μάθημα");
            Console.WriteLine("Πατήστε 7 για να δείτε όλες τις εργασίες ανα μάθητη"); 
            Console.WriteLine("Πατήστε 8 για να δείτε να εισάγετε μια ημερομηνία "); 
            Console.WriteLine("Πατήστε E ή e για έξοδο");
            Console.ResetColor();
            
        }
    }

}

