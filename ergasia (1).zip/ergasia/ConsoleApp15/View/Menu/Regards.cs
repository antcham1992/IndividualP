﻿using System;

namespace ConsoleApp15
{
   
        class Regards
        {
            public static void Welcome()
            {
                Console.WriteLine();
                Console.WriteLine("ΚΑΛΩΣΗΡΘΑΤΕ");
            }

        }
    }


