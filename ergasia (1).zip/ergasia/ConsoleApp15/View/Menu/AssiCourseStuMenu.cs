﻿using System;

namespace Final.Application
{
    class AssiCourseStuMenu
    {
        public static void Menu()
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1 - Για να δείτε τα όλα τα assignment ανά μαθητή ");            
            Console.WriteLine("2 - Για να επιστρέψετε στο αρχικό μενού");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
    }


