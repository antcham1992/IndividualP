﻿using System;

namespace Final.Application
{
    class DateMenu
    {
        public static void Menu()
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1- Για να δείτε ολους τους μαθητες που έχου να παραδώσουνε εργασίες");
            Console.WriteLine("2- Για να επιστρέψετε στο αρχικό μενού");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
    }


