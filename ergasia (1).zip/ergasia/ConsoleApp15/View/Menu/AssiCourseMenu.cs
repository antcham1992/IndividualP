﻿using System;

namespace Final.Application
{
    class AssiCourseMenu
    {
        public static void Menu()
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1 - Για να δείτε τα όλα τα assignment ανά μάθημα ");            
            Console.WriteLine("2 - Για να επεξεργαστείτε");
            Console.WriteLine("3 - Για να διαγράψετε assignment απο το μάθημα");
            Console.WriteLine("4 - Για να διαγράψετε  το μάθημα μαζί με  τα assignment του");
            Console.WriteLine("5 - Για να επιστρέψετε στο αρχικό μενού");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
    }


