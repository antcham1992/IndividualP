﻿using System;

namespace Final.Application
{
    class StudentCourseMenu
    {
        public static void Menu()
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1 - Για να δείτε τα όλους τους μαθητές ανά Mαθήμα ");            
            Console.WriteLine("2 - Για να επεξεργαστείτε");
            Console.WriteLine("3 - Για να διαγράψετε μαθητή απο το μάθημα");
            Console.WriteLine("4 - Για να διαγράψετε  το μάθημα μαζί με τους μαθητές του");
            Console.WriteLine("5 - Για να επιστρέψετε στο αρχικό μενού");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
    }


