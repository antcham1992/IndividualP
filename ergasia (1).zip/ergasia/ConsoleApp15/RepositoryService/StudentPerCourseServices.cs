﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class StudentPerCourseServices
    {
        private MyDatabase db = new MyDatabase();
        public List<Courses> GetCourses()

        {
            return db.Courses;
        }

        public void Edit(int coId,int stuId)
        {
            var student = db.Student.Find(x => x.Id == stuId);
            var course = db.Courses.Find(x => x.Id == coId);

            course.Student.Add(student);
        }

        public void Delete(int coId)
        {
            var course = db.Courses.Find(x => x.Id == coId);
            db.Courses.Remove(course);
            
        }
        public void DeleteStudent(int coId, int stuId)
        {
            var student = db.Student.Find(x => x.Id == stuId);
            var course = db.Courses.Find(x => x.Id == coId);

            course.Student.Remove(student);
        }

    }
}
