﻿using ConsoleApp15.MyData1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class DateServices
    {
         MyDatabase db = new MyDatabase();
        public List<Assignment> GetAssignment()
        {
            return db.Assignment;
        }
        
      
        
    }
}

