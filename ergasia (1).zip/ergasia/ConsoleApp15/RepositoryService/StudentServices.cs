﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class StudentServices
    {
        private MyDatabase db = new MyDatabase();
        public List<Student> GetStudent()

        {
            return db.Student;
        }

        public void Add(List<Student> s,int number)
        {
            int lastId1 = db.Student[db.Student.Count - 1].Id;
            for (int i = 0; i < number; i++)
            {
                s[i].Id = lastId1 + 1;
                lastId1++;
            }
            db.Student.AddRange(s);
        }
        public void Edit(int studentId, Student newStudent)
        {
            var student = db.Student.FindIndex(x => x.Id == studentId);
            db.Student[student] = newStudent;
        }
        public void Delete(int studentId)
        {
            var student = db.Student.Find(x => x.Id == studentId);
            db.Student.Remove(student);
        }
    }
}
