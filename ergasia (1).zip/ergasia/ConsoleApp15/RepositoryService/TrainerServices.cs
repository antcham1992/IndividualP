﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp15;
using ConsoleApp15.view;

namespace ConsoleApp15.RepositoryService
{
    class TrainerServices
    {
      public  MyDatabase db = new MyDatabase();

       
        public  List<Trainer> GetTrainers()

        {
           
            return db.Trainer;
        }

        public void Add(List<Trainer> t,int number)   
        {
            int lastId1 = db.Trainer[db.Trainer.Count - 1].Id;
            for (int i = 0; i < number; i++)
            {
                t[i].Id = lastId1 + 1;
                lastId1++;
            }

           
            db.Trainer.AddRange(t);
        }
        public void Edit(int trainerId,Trainer newTrainer)
        {
            var trainer = db.Trainer.FindIndex(x => x.Id == trainerId);
            db.Trainer[trainer] = newTrainer;
        }
        public void Delete(int trainerId)
        {
            var trainer = db.Trainer.Find(x => x.Id == trainerId);
            db.Trainer.Remove(trainer);
        }
    }
}
