﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class AssignmentPerCoursePerStudentServices
    {
         MyDatabase db = new MyDatabase();
        public  List<Courses> GetCourses()

        {
            return db.Courses;
        }

      
    }
}
