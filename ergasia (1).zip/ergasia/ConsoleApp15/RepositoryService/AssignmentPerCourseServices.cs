﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class AssignmentPerCourseServices
    {
        private MyDatabase db = new MyDatabase();
        public List<Courses> GetCourses()

        {
            return db.Courses;
        }

        public void Edit(int coId, int asId)
        {
            var ass = db.Assignment.Find(x => x.Id == asId);
            var course = db.Courses.Find(x => x.Id == coId);

           course.Assi.Add(ass);
        }

        public void Delete(int coId)
        {
            var course = db.Courses.Find(x => x.Id == coId);
            db.Courses.Remove(course);

        }
        public void DeleteStudent(int coId, int asId)
        {
            var assi = db.Assignment.Find(x => x.Id == asId);
            var course = db.Courses.Find(x => x.Id == coId);

            course.Assi.Remove(assi);
        }
    }
}
