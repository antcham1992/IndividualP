﻿using ConsoleApp15.MyData1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class AssignmentServices
    {
         MyDatabase db = new MyDatabase();
        public List<Assignment> GetAssignment()
        {
            return db.Assignment;
        }

        public void Add(Assignment a,List<SmallAssigment> sa)
        {
            int lastId = db.Assignment[db.Assignment.Count - 1].Id;
            a.Id = lastId + 1;
           int lastId1 = db.SmallAssigment[db.SmallAssigment.Count - 1].Id;
            for (int i = 0; i < 7; i++)
            {
             sa[i].Id = lastId1 + 1;
             lastId1++;
            }
            AssignSmallAssi.Pair(a,sa);
            db.SmallAssigment.AddRange(sa);
            db.Assignment.Add(a);
        }
        public void Edittitle(int assigmentId,Assignment newassi)
        {
            var assignment = db.Assignment.FindIndex(x => x.Id == assigmentId);
            db.Assignment[assignment] = newassi;

        }
        public void EditRow(int assigmentId, int SmallassigmentId, Assignment newAssigment,SmallAssigment newsmallAssigment)
        {
           
            var assignment = db.Assignment.Find(x => x.Id == assigmentId);
            var y= assignment.smallAssigment.FindIndex(x =>x.Id== SmallassigmentId);
            assignment.smallAssigment[y] = newsmallAssigment;
           
        }
        public void Delete(int assigmentId)
        {
            var assignment = db.Assignment.Find(x => x.Id == assigmentId);
            db.Assignment.Remove(assignment);
        }

        
    }
}

