﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class TrainerPerCourseServices
    {
        private MyDatabase db = new MyDatabase();
        public List<Courses> GetCourses()

        {
            return db.Courses;
        }

        public void Edit(int coId, int trId)
        {
            var trainer = db.Trainer.Find(x => x.Id == trId);
            var course = db.Courses.Find(x => x.Id == coId);

            course.Trainer.Add(trainer);
        }

        public void Delete(int coId)
        {
            var course = db.Courses.Find(x => x.Id == coId);
            db.Courses.Remove(course);

        }
        public void DeleteStudent(int coId, int trId)
        {
            var trainer = db.Trainer.Find(x => x.Id == trId);
            var course = db.Courses.Find(x => x.Id == coId);

            course.Trainer.Remove(trainer);
        }
    }
}
