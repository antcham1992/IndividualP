﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.RepositoryService
{
    class CoursesServices
    {
        private MyDatabase db = new MyDatabase();
        public  List<Courses> GetCourses()

        {
            return db.Courses;
        }

        public void GetCourseByTitle(string title)
        {

        }
        public void Add(List<Courses> c,int number)

        {
            int lastId1 = db.Courses[db.Courses.Count - 1].Id;
            int lastId2 = db.Courses[db.Courses.Count - 1].Stream;
            for (int i = 0; i < number; i++)
            {
                c[i].Id = lastId1 + 1;
                c[i].Stream = lastId2 + 1;
                lastId1++;
                lastId2++;
            }
           
            db.Courses.AddRange(c);
            
        }
        public void Edit(int CourseId,int stream, Courses newCourse)
        {
            var course = db.Courses.FindIndex(x => x.Id == CourseId&&x.Stream==stream);
            
            db.Courses[course] = newCourse;
        }
        public void Delete(int CourseId)
        {
            var course = db.Courses.Find(x => x.Id == CourseId);
            db.Courses.Remove(course);
        }
    }
}
