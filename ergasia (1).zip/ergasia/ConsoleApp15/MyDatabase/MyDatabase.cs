﻿using ConsoleApp15;
using ConsoleApp15.Data.NewFolder1;
using ConsoleApp15.MyData.PairClass;
using ConsoleApp15.MyData1;
using ConsoleApp15.MyData2.PairClass;
using ConsoleApp15.MyData3.PairClass;
using System;
using System.Collections.Generic;

namespace ConsoleApp15
{
    class MyDatabase
    {

       
        public List<Courses> Courses { get; set; }
        public List<Student> Student { get; set; }
        public List<Trainer> Trainer { get; set; }  
        public List<Assignment> Assignment { get; set; }
        public List<SmallAssigment> SmallAssigment { get; set; }
       
        public  MyDatabase()

        {
          

            #region Instance_Assignment
            Assignment a1 = new Assignment(1,"Αssignment in C#");
            Assignment a2 = new Assignment(2, "Αssignment in Python");
            Assignment a3 = new Assignment(3, "Αssignment in Javascript");
            Assignment a4 = new Assignment(4, "Αssignment in Java");
            #endregion


            #region Synthetic_AdditionalCourse

            Courses c1 = new Courses(1,"C#", 15, "Full-time", new DateTime(2022, 1, 19), new DateTime(2022, 4, 19));
            Courses c2 = new Courses(2,"C#", 16, "Part-time", new DateTime(2022, 1, 19), new DateTime(2022, 7, 19));

            Courses c3 = new Courses(3,"Python", 17, "Full-time", new DateTime(2022, 1, 20), new DateTime(2022, 4, 20));
            Courses c4 = new Courses(4,"Python", 18, "Part-time", new DateTime(2022, 1, 20), new DateTime(2022, 4, 20));

            Courses c5 = new Courses(5,"Javascript", 19, "Full-time", new DateTime(2022, 1, 25),new DateTime(2022, 4, 25));
            Courses c6 = new Courses(6,"Javascript", 20, "Part-time", new DateTime(2022, 1, 25), new DateTime(2022, 7, 25));

            Courses c7 = new Courses(7,"Java", 21, "Full-time", new DateTime(2022, 1, 29), new DateTime(2022, 4, 29));
            Courses c8 = new Courses(8,"Java", 22, "Part-time", new DateTime(2022, 1, 29), new DateTime(2022, 7, 29));

            #endregion

            #region Synthetic_Student
            Student s1 = new Student(1,"Bill", "Orfanos", new DateTime(1980, 8, 26), 2000);

            Student s2 = new Student(2,"Theodoros", "Doe", new DateTime(1980, 1, 16), 5000);

            Student s3 = new Student(3,"Pinelopi", "Xatzaki", new DateTime(1992, 8, 5), 7000);

            Student s4 = new Student(4,"Axileas", "Stefanidis", new DateTime(1997, 8, 5), 8000);

            Student s5 = new Student(5,"Kostas", "Kalotinis", new DateTime(1997, 8, 12), 1500);

            Student s6 = new Student(6,"Dimitris", "Anastasios", new DateTime(1987, 2, 18), 1500);

            Student s7 = new Student(7,"Michalis", "Xatzis", new DateTime(1997, 2, 18), 2500);
            Student s8 = new Student(8,"Elenh", "Psoma", new DateTime(1980, 6, 16), 4000);
            Student s9 = new Student(9,"Foteinh", "Kalogeirou", new DateTime(1987, 7, 28), 3500);
            Student s10 = new Student(10,"Lamprinh", "Laskarakh", new DateTime(1975, 2, 18), 1500);
            Student s11 = new Student(11,"Euaggelia", "Fanaraki", new DateTime(1992, 5, 18), 3000);


            #endregion

            #region Synthetic_Trainer
            Trainer t1 = new Trainer(1,"Hector", "Gkatsos", "C#");

            Trainer t2 = new Trainer(2,"John", "Doe", "Python");

            Trainer t3 = new Trainer(3,"Helene", "Xatzaki", "Javascript");

            Trainer t4 = new Trainer(4,"Leonidas", "Stefanidis", "Java");

            Trainer t5 = new Trainer(5,"Andreas", "Orfanos", "Java");

            Trainer t6 = new Trainer(6,"George", "Abramidis", "Python");
            
            #endregion

            #region Synthetic_SmallAssignm
            SmallAssigment as1 = new SmallAssigment(1,"Assignment_Part_A", "Styles/Function ",new DateTime(2021, 12, 30), 100,100);
            SmallAssigment as2 = new SmallAssigment(2,"Assignment_Part_B", "Objects ", new DateTime(2022,2,15),100,100);
            SmallAssigment as3 = new SmallAssigment(3,"Assignment_Part_C", "Reflection ",new DateTime(2022, 3, 6),100,100);
            SmallAssigment as4 = new SmallAssigment(4,"Assignment_Part_D", "Reflection ",new DateTime(2022, 3, 20), 100,100);
            SmallAssigment as5 = new SmallAssigment(5,"Assignment_Part_E", "Data-Centric",new DateTime(2022, 3, 29), 100,100);
            SmallAssigment as6 = new SmallAssigment(6,"Project_A","Individual project",new DateTime(2022, 4, 10), 100,100);
            SmallAssigment as7 = new SmallAssigment(7,"Project_B","Team project",new DateTime(2022, 4, 30),100, 100);
            SmallAssigment as8 = new SmallAssigment(8,"Assignment_Part_A"," Function",new DateTime(2021,12,30),100,100);
            SmallAssigment as9 = new SmallAssigment(9,"Assignment_Part_B"," Objects",new DateTime(2022,2,15),100,100);
            SmallAssigment as10 = new SmallAssigment(10,"Assignment_Part_C"," Reflection",new DateTime(2022,3,6),100,100);
            SmallAssigment as11 = new SmallAssigment(11,"Assignment_Part_D"," Reflection",new DateTime(2022,3,20),100,100);
            SmallAssigment as12 = new SmallAssigment(12,"Assignment_Part_E"," Data-Centric",new DateTime(2022,3,29),100,100);
            SmallAssigment as13 = new SmallAssigment(13,"Project_A","Individual project", new DateTime(2022,4,10),100,100);
            SmallAssigment as14 = new SmallAssigment(14,"Project_B"," Team project", new DateTime(2022,4,30),100,100);
            SmallAssigment as15 = new SmallAssigment(15,"Assignment_Part_A"," Function", new DateTime(2021,12,30),100,100);
            SmallAssigment as16 = new SmallAssigment(16,"Assignment_Part_B"," Objects" ,new DateTime(2022,2,15),100,100);
            SmallAssigment as17 = new SmallAssigment(17,"Assignment_Part_C"," Reflection",new DateTime(2022,3,6),100,100);
            SmallAssigment as18 = new SmallAssigment(18,"Assignment_Part_D"," Reflection",new DateTime(2022,3,20),100,100);
            SmallAssigment as19 = new SmallAssigment(19,"Assignment_Part_E"," Data-Centric",new DateTime(2022,3,29),100,100);
            SmallAssigment as20 = new SmallAssigment(20,"Project_A"," Individual project",new DateTime(2022,4,10),100,100);
            SmallAssigment as21 = new SmallAssigment(21,"Project_B"," Team project", new DateTime(2022,4,30),100,100);
            SmallAssigment as22 = new SmallAssigment(22,"Assignment_Part_A","Styles/Function",new DateTime(2021, 12, 30),100,100);
            SmallAssigment as23 = new SmallAssigment(23,"Assignment_Part_B","Objects",new DateTime(2022,2,15),100,100);
            SmallAssigment as24 = new SmallAssigment(24,"Assignment_Part_C","Reflection ",new DateTime(2022,3,6),100,100);
            SmallAssigment as25 = new SmallAssigment(25,"Assignment_Part_D","Reflection",new DateTime(2022,3,20),100,100);
            SmallAssigment as26 = new SmallAssigment(26,"Assignment_Part_E","Data-Centric",new DateTime(2022,3,29),100,100);
            SmallAssigment as27 = new SmallAssigment(27,"Project_A","Individual project",new DateTime(2022,4,10),100,100);
            SmallAssigment as28 = new SmallAssigment(28,"Project_B","Team project",new DateTime(2022,4,30),100,100);



            #endregion


            #region Relate_classes

            //Student per course 
            CourseStudent.Pair(c1, new List<Student>() { s1, s2, s3, s4,s9 });
            CourseStudent.Pair(c2, new List<Student>() { s5,s6,s7,s8});
            CourseStudent.Pair(c3, new List<Student>() { s1, s2, s3, s4,s9});
            CourseStudent.Pair(c4, new List<Student>() { s5,s6,s7,s8 });
            CourseStudent.Pair(c5, new List<Student>() { s1, s2, s3, s4,s9 });
            CourseStudent.Pair(c6, new List<Student>() { s5,s6,s7,s8});
            CourseStudent.Pair(c7, new List<Student>() { s1, s2, s3, s4,s9 });
            CourseStudent.Pair(c8, new List<Student>() { s5, s6 ,s10,s11});

            // Course per student
            CourseStudent.Pair1(s1, new List<Courses>() { c1, c3, c5, c7 });
            CourseStudent.Pair1(s2, new List<Courses>() { c1, c3, c5, c7 });
            CourseStudent.Pair1(s3, new List<Courses>() { c1, c3, c5, c7 });
            CourseStudent.Pair1(s4, new List<Courses>() { c1, c3, c5, c7 });
            CourseStudent.Pair1(s5, new List<Courses>() { c2, c4, c6, c8 });
            CourseStudent.Pair1(s6, new List<Courses>() { c2, c4, c6, c8 });
            CourseStudent.Pair1(s7, new List<Courses>() { c2, c4, c6});
            CourseStudent.Pair1(s8, new List<Courses>() { c2, c4, c6});
            CourseStudent.Pair1(s9, new List<Courses>() { c1, c3, c5, c7 });
            CourseStudent.Pair1(s10, new List<Courses>() { c8 });
            CourseStudent.Pair1(s11, new List<Courses>() { c8 });

            //Trainer per course
            CourseTrainer.Pair(c1,new List<Trainer>() {t1});
            CourseTrainer.Pair(c2,new List<Trainer>() {t1});
            CourseTrainer.Pair(c3,new List<Trainer>() {t2,t6});
            CourseTrainer.Pair(c4,new List<Trainer>() {t2,t6});
            CourseTrainer.Pair(c5,new List<Trainer>() {t3});
            CourseTrainer.Pair(c6,new List<Trainer>() {t3});
            CourseTrainer.Pair(c7,new List<Trainer>() {t4,t5});
            CourseTrainer.Pair(c8,new List<Trainer>() {t4,t5});

            //Course per Trainer
            CourseTrainer.Pair1(t1, new List<Courses>() { c1, c2 });
            CourseTrainer.Pair1(t2, new List<Courses>() { c3, c4 });
            CourseTrainer.Pair1(t3, new List<Courses>() { c5, c6 });
            CourseTrainer.Pair1(t4, new List<Courses>() { c7, c8 });
            CourseTrainer.Pair1(t5, new List<Courses>() { c7, c8 });
            CourseTrainer.Pair1(t6, new List<Courses>() { c3, c4 });

            //SmallAsignment per assignme
            AssignSmallAssi.Pair(a1, new List<SmallAssigment>() { as1, as2, as3, as4, as5, as6, as7 });
            AssignSmallAssi.Pair(a2, new List<SmallAssigment>() { as8, as9, as10, as11, as12, as13, as14 });
            AssignSmallAssi.Pair(a3, new List<SmallAssigment>() { as15, as16, as17, as18, as19, as20, as21 });
            AssignSmallAssi.Pair(a4, new List<SmallAssigment>() { as22, as23, as23, as24, as25, as26, as27,as28 });

            // smallAsignment per Assign
            AssignSmallAssi.Pair1(as1, a1);
            AssignSmallAssi.Pair1(as2, a1);
            AssignSmallAssi.Pair1(as3, a1);
            AssignSmallAssi.Pair1(as4, a1);
            AssignSmallAssi.Pair1(as5, a1);
            AssignSmallAssi.Pair1(as6, a1);
            AssignSmallAssi.Pair1(as7, a1);
            AssignSmallAssi.Pair1(as8, a2);
            AssignSmallAssi.Pair1(as9, a2);
            AssignSmallAssi.Pair1(as10, a2);
            AssignSmallAssi.Pair1(as11, a2);
            AssignSmallAssi.Pair1(as12, a2);
            AssignSmallAssi.Pair1(as13, a2);
            AssignSmallAssi.Pair1(as14, a2);
            AssignSmallAssi.Pair1(as15, a3);
            AssignSmallAssi.Pair1(as16, a3);
            AssignSmallAssi.Pair1(as17, a3);
            AssignSmallAssi.Pair1(as18, a3);
            AssignSmallAssi.Pair1(as19, a3);
            AssignSmallAssi.Pair1(as20, a3);
            AssignSmallAssi.Pair1(as21, a3);
            AssignSmallAssi.Pair1(as22, a4);
            AssignSmallAssi.Pair1(as23, a4);
            AssignSmallAssi.Pair1(as24, a4);
            AssignSmallAssi.Pair1(as25, a4);
            AssignSmallAssi.Pair1(as26, a4);
            AssignSmallAssi.Pair1(as27, a4);
            AssignSmallAssi.Pair1(as28, a4);
            // Assign per course
            AssignCourse.Pair(c1,a1);
            AssignCourse.Pair(c2,a1);
            AssignCourse.Pair(c3,a2);
            AssignCourse.Pair(c4,a2);
            AssignCourse.Pair(c5,a3);
            AssignCourse.Pair(c6,a3);
            AssignCourse.Pair(c7,a4);
            AssignCourse.Pair(c8,a4);


            //Course per Assign
            AssignCourse.Pair1(a1, new List<Courses>() { c1, c2 });
            AssignCourse.Pair1(a2, new List<Courses>() { c3, c4 });
            AssignCourse.Pair1(a3, new List<Courses>() { c5, c6 });
            AssignCourse.Pair1(a4, new List<Courses>() { c7, c8 });

            //Assignment per student
            AssiStudent.Pair(s1,a1);
            AssiStudent.Pair(s2,a2);
            AssiStudent.Pair(s3,a3);
            AssiStudent.Pair(s4,a4);
            AssiStudent.Pair(s5,a1);
            AssiStudent.Pair(s6,a1);
            AssiStudent.Pair(s7,a3);
            AssiStudent.Pair(s8,a2);
            AssiStudent.Pair(s9,a3);
          AssiStudent.Pair(s10,a4);
            AssiStudent.Pair(s11,a4);


            //Student per Assignment
            AssiStudent.Pair1(a1, new List<Student>() { s1, s5, s6 });
            AssiStudent.Pair1(a2, new List<Student>() { s2, s8 });
            AssiStudent.Pair1(a3, new List<Student>() { s3, s7, s9 });
            AssiStudent.Pair1(a4, new List<Student>() { s4, s10, s11 });




            #endregion

            #region Populate
            Courses = new List<Courses>() {c1,c2,c3,c4,c5,c6,c7,c8};
            
            Student = new List<Student>() { s1, s2, s3, s4, s5, s6,s7,s8,s9,s10,s11};
            
            Trainer = new List<Trainer>() {t1,t2,t3,t4,t5,t6};
            
            Assignment = new List<Assignment>() { a1,a2,a3,a4};

            SmallAssigment = new List<SmallAssigment>() { as1,as2,as3,as4,as5,as6,as7, as8, as9, as10, as11, as12, as13, as14 
            ,as15,as16,as17,as18,as19,as20,as21, as22, as23, as24, as25, as26, as27, as28};
           

        #endregion


        }
}
}
