﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.Data.NewFolder1
{
    class CourseStudent
    {
        public static void Pair(Courses c, List<Student> s)
        {
            c.Student = s;
        }
        public static void Pair1(Student s, List<Courses> c)
        {
            s.Courses = c;
        }
    }
}
