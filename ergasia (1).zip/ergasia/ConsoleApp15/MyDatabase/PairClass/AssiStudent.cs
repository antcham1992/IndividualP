﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.MyData3.PairClass
{
    class AssiStudent
    {
        public static void Pair(Student s,Assignment a)
        {
            foreach (var item in a.smallAssigment)
            {
                item.Student.Add(s);
            }
        }
        public static void Pair1( Assignment a , List<Student> s)
        {
            a.Student.AddRange(s);

        }
    }
}
