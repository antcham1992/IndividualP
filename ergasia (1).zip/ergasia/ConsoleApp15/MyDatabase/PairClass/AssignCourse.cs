﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.MyData2.PairClass
{
    class AssignCourse
    {
        public static void Pair(Courses c,Assignment s)
        {
            c.Assi.Add(s);
        }
        public static void Pair1( Assignment a,List<Courses>c)
        {
            a.Courses.AddRange(c);
        }
    }
}
