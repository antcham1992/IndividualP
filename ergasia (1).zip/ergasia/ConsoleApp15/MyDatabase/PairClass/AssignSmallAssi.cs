﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.MyData1
{
    class AssignSmallAssi
    {
        public static void Pair(Assignment a,List<SmallAssigment> sa)
        {
            a.smallAssigment = sa;

        }
        public static void Pair1( SmallAssigment sa, Assignment a)
        {
             sa.Assignment=a;
        }
    }
}
