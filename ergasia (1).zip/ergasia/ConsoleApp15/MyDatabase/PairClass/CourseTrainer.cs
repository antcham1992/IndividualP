﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15.MyData.PairClass
{
    class CourseTrainer
    {
        public static void Pair(Courses c,List<Trainer> t)
        {
            c.Trainer = t;
        }
        public static void Pair1(Trainer t,List<Courses> c)
        {
            t.Courses = c;
        }
    }
}
